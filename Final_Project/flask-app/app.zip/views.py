# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

# Flask modules
from flask   import render_template, request, redirect, url_for, flash, session, json
from jinja2  import TemplateNotFound

# App modules
from app import app, db
from app.models import Member, Membership
import datetime

# App main route + generic routing
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/challenges_init')
def challenges_init():
    members = Member.query.all()
    return render_template('challenges_init.html', members=members)

@app.route('/challenges_sent')
def challenges_sent():
    return render_template('challenges_sent.html')

@app.route('/challenges_inbox')
def challenges_inbox():
    return render_template('challenges_inbox.html')

@app.route('/challenges_form')
def challenges_form():
    return render_template('challenges_form.html')

@app.route('/membership_registration')
def membership_registration():
    return render_template('membership_registration.html')

@app.route('/registration_success')
def registration_success():
    return render_template('membership_reg_success')

@app.route('/submit_membership_registration', methods=["GET", "POST"])
def submit_membership_registration():
    # Get the variable and form validation
    fname = request.form.get('fname')
    lname = request.form.get('lname')
    meid = request.form.get('meid')
    msid = request.form.get('msid')
    plan = request.form.get('plan')

    # Form validation
    error = False
    
    if not meid :
        flash('Please enter your memberid')
        error = True
        
    if not fname:
        flash('Please enter your FirstName')
        error = True
        
    if not plan:
        flash('Please select your Membership Plans')
        error = True
        
    if not error:
        if not msid:
            meid = int(meid)
            plan = int(plan)
            year = datetime.datetime.now().year
            month = datetime.datetime.now().month
            day = datetime.datetime.now().day
            dueday = day + 7
            endyear = year + plan
            startdate = f"{year}-{month}-{day}"
            enddate = f"{endyear}-{month}-{day}"
            duedate = f"{year}-{month}-{dueday}"
            amount = float(plan * 100)
            membership = Membership(
                MEID = meid,
                StartDate = startdate,
                EndDate = enddate,
                InvoiceDate = startdate,
                DueDate = duedate,
                Amount = amount         
            )
            payamount = 100 * plan
            tax = payamount * 0.1
            totalpay = payamount + tax
            db.session.add(membership)
            db.session.commit()
            db.session.refresh(membership)
            session['msid'] = msid
            flash(f'Your membership ID #{membership.MSID} is added')
            return render_template('membership_reg_success.html', membership = membership, tax = tax, totalpay = totalpay, plan = plan)
        else:
            plan = int(plan)
            enddate = db.session.query(Membership.EndDate).filter(Membership.MSID == msid).scalar()
            endyear = enddate.year + plan
            month = enddate.month
            day = enddate.day
            enddate = f"{endyear}-{month}-{day}"
            membership = Membership.query.get(msid)
            membership.EndDate = enddate
            db.session.commit()
            payamount = 100 * plan
            tax = payamount * 0.1
            totalpay = payamount + tax
            session['msid'] = msid
            flash(f"Your Membership ID #{msid}'s EndDate has been extended to {enddate}")
            return render_template('membership_reg_success.html', membership = membership, tax = tax, totalpay = totalpay, plan = plan)
            
    return render_template('membership_registration.html', fname=fname, lname=lname, meid=meid, msid=msid, plan=plan)

@app.route('/payment_success', methods=['GET','POST'])
def payment_success():
    msid = request.form.get('msid')
    year = datetime.datetime.now().year
    month = datetime.datetime.now().month
    day = datetime.datetime.now().day
    startdate = f"{year}-{month}-{day}"
    membership = Membership.query.get(msid)
    membership.PaidDate = startdate
    db.session.commit()
    return render_template('membership_payment_success.html')

@app.route('/ask_for_chart')
def chartform():
    membership = Membership.query.all()
    year = sorted(set([m.EndDate.year for m in membership]))
    return render_template('membership_ask_for_chart.html', year = year)

@app.route('/chart', methods=["GET", "POST"])
def chart():
    membership = Membership.query.all()
    year = int(request.form.get('year'))
    paynum = 0
    unpaynum = 0
    # today = datetime.datetime.now().date()
    for m in membership:
        amount = int(m.Amount)
        plan = amount / 100
        EndDate = m.EndDate
        PaidDate = m.PaidDate
        PaidJudgeDate = EndDate - datetime.timedelta(days=plan*366)
        allyear = sorted(set([m.EndDate.year for m in membership]))

        if (m.PaidDate is None or PaidDate<PaidJudgeDate) and (m.EndDate.year == year):
            unpaynum += 1
        elif m.EndDate.year == year:
            paynum += 1
    structure1 = {
        "label":"not pay",
        "value":str(unpaynum)}
    structure2={
        "label":"paid",
        "value":str(paynum)
    }
    structure = [structure1, structure2]
    chartData = json.dumps(structure)
    return render_template('membership_chart.html', chartData = chartData, year=year, allyear = allyear)

@app.route('/extention')
def extend():
    meid = session.get('meid')
    plan = request.form.get('plan')
    plan = int(plan)
    memberships = db.session.query(Membership).filter(Membership.MEID == meid)
    for m in memberships:
        year = int(m.EndDate.year)
        month = int(m.EndDate.month)
        day = int(m.EndDate.day)
        membership = m
    extended_EndDate = f'{year+plan}-{month}-{day}'
    amount = plan * 100
    paidyear = datetime.datetime.now().year
    paidmonth = datetime.datetime.now().month
    paidday = datetime.datetime.now().day
    paidDate = f'{paidyear}-{paidmonth}-{paidday}'
    membership.EndDate = extended_EndDate
    membership.PaidDate = paidDate
    membership.InvoiceDate = paidDate
    membership.Amount = amount
    db.session.commit()
    return render_template('membership_payment_success.html')
    
@app.route('/delete_ms/<int:ms_id>', methods=['POST', 'GET'])
def delete_ms(ms_id):
    membership = Membership.query.get(ms_id)
    if membership is not None:
        db.session.delete(membership)
        db.session.commit()
        flash(f"Membership ID #{ms_id} has been deleted successfully.")
    memberships = Membership.query.all()
    now = datetime.datetime.now()
    return render_template('membership_admin_view.html', memberships=memberships, now=now)

    
@app.route('/judge')
def judge_ms():
    meid = session.get('meid')
    membership = db.session.query(Membership).filter(Membership.MEID == meid).all()
    if membership is None:
        return render_template('membership_registration.html')
    return render_template('membership_extend.html')

@app.route('/membership_list')
def membership_list():
    memberships = Membership.query.all()
    now = datetime.datetime.now()
    return render_template('membership_admin_view.html', memberships = memberships, now = now)